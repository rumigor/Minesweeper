package com.lenecoproekt.minesweeper.logic

import java.util.*

class Logic(val height: Int, val width: Int, val minesNumber: Int) {
    private val gameField: Array<Array<GameObject?>> = Array(height) { arrayOfNulls(width) }

    init {
        fillGameField()
        loadMines()
    }

    private fun fillGameField() {
        loadMines()
        loadNumbers()
    }

    private fun loadMines() {
        var countMines = 0
        while (countMines != minesNumber) {
            val i = Random().nextInt(height)
            val j = Random().nextInt(width)
            if (gameField[i][j] == null) {
                gameField[i][j] = GameObject(i, j, true)
                countMines++
            }
        }
        for (i in 0 until height) {
            for (j in 0 until width) {
                if (gameField[i][j] == null) {
                    gameField[i][j] = GameObject(i, j, false)
                }
            }
        }
    }

    private fun loadNumbers() {
        for (i in 0 until height) {
            for (j in 0 until width) {
                gameField[i][j]?.let {
                    if (!it.isMine) {
                        var n = 0
                        val result = getNeighbors(it)
                        for (k in result.indices) {
                            if (result[k].isMine) n++
                        }
                        it.countMineNeighbors = n
                    }
                }
            }
        }
    }

    fun openTile() {

    }

    private fun getNeighbors(gameObject: GameObject): List<GameObject> {
        val result: MutableList<GameObject> = ArrayList()
        for (y in gameObject.y - 1..gameObject.y + 1) {
            for (x in gameObject.x - 1..gameObject.x + 1) {
                if (y < 0 || y >= width) {
                    continue
                }
                if (x < 0 || x >= height) {
                    continue
                }
                if (gameField[x][y] === gameObject) {
                    continue
                }
                gameField[x][y]?.let {
                    result.add(it)
                }

            }
        }
        return result
    }


}